package com.paytm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaytmPaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaytmPaymentServiceApplication.class, args);
	}

}
